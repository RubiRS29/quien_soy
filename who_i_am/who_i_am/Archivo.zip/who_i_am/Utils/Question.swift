//
//  Question.swift
//  who_i_am
//
//  Created by MARIA DE LA PAZ SANTIAGO CORTES on 02/04/24.
//

import Foundation

struct Question {
    var id: Int
    var question: String
    var optionOne: String
    var optionTwo: String
    var optionThree: String
    var optionFour: String
}
