//
//  User.swift
//  who_i_am
//
//  Created by MARIA DE LA PAZ SANTIAGO CORTES on 02/04/24.
//

import Foundation


struct User {
    let username:String
}
